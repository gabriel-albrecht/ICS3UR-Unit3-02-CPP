// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Nov 2020
// This program is for number guessing

#include <iostream>

int main() {
    const int guessing = 7;
    int number;

    // input
    std::cout << "Pick a number between 0-9: ";
    std::cin >> number;
    std::cout << "" << std::endl;

    // process
    if (number == guessing) {
        // output
        std::cout << "Congratulations! You picked the right number!";
    }
}
